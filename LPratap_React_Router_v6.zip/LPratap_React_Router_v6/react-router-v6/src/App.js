import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';

import Home from './components/Home';
import About from './components/About';
import Contact from './components/Contact';
import Services from './components/Services';
import Carrer from './components/Carrer';


import './App.css';

function App() {

  return (
    <div className="App">
      <BrowserRouter>
        <nav>
          <h1>Web Menu Navigation</h1>
          <Link to="/">Home</Link>
          <Link to="/about">About</Link>
          <Link to='/contact'>Contact</Link>
          <Link to='/services'>Services</Link>
          <Link to='/carrer'>Carrer</Link>
        </nav>
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route path='/about' element={<About />} />
          <Route exact path='contact' element={<Contact />} />
          <Route exact path="/services" element={<Services />} />
          <Route exact path="/carrer" element={<Carrer /> } />
        </Routes>
      </BrowserRouter>
   
    </div>
  );
}

export default App;
