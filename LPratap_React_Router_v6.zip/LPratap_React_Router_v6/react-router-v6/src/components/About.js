

export default function About() {
  return (
    <div className="content">
      <h2>About</h2>
    </div>
  )
}
