export default function Home() {
  return (
    <div className="content">
      <h1>Home</h1>
      </div>
  )
}
