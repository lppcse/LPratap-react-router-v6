
export default function Services() {
  return (
    <div className="content">
      <h2>Services</h2>
    </div>
  )
}
