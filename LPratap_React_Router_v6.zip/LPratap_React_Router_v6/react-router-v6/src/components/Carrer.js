

export default function Carrer() {
  return (
    <div className="content">
      <h2>Carrer</h2>
    </div>
  )
}
