

export default function Contact() {
  return (
    <div className="content">
      <h1>Contact</h1>
    </div>
  )
}
